from fastapi import FastAPI
from fastapi import HTTPException, status
from models import Curso
from fastapi import Response

app = FastAPI()

cursos = {
    1: {
        "nome": "python",
        "aulas": 20,
        "horas": 80,
        "instrutor": "Cleber"
    },
    2: {
        "nome": "Java",
        "aulas": 15,
        "horas":60,
        "instrutor": "Leonardo"
    }
}

@app.get("/cursos")
async def get_cursos():
    return cursos

@app.get("/cursos/{curso_id}")
async def get_curso(curso_id: int):
    try:
        curso_1 = cursos[curso_id]
        #curso_1.update({"id": curso_id})
        return curso_1
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Curso Não Encontrado.')

@app.post('/cursos', status_code=status.HTTP_201_CREATED)
async def post_curso(curso: Curso):
    next_id=len(cursos) + 1
    if next_id not in cursos:
        cursos[next_id] = curso
        del curso.id
        return curso
    else:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=f"Já existe um curso com o ID {curso.id}")

@app.put('/cursos/{curso_id}')
async def put_curso(curso_id: int, curso: Curso):
    if curso_id in cursos:
        cursos[curso_id] = curso
        return curso
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Esse Curso Não Existe.")

@app.delete('/cursos/{curso_id}')
async def delete_curso(curso_id: int):
    if curso_id in cursos:
        del cursos[curso_id]
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Esse Curso Não Existe.")

if __name__ == '__main__':
    import uvicorn
    uvicorn.run("teste:app", host='127.0.0.1', port=8000, reload=True)